﻿namespace ContactosApp.Models;

public class EntidadFederativa
{
    public long Id { get; set; }
    public string? Nombre { get; set; }
}