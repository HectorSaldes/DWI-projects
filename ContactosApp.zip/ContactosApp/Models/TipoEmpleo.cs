﻿namespace ContactosApp.Models;

public class TipoEmpleo
{
    public long Id { get; set; }
    public string? Nombre { get; set; }
}